	var coinsNums = [240000, 640000, 1440000, 3400000, 10800000, 25600000];
	var rollsNums = ['30', '80', '180', '425', '1400', '3200'];
	var rollsExtraNums = ['50', '160', '450', '1250', '5000', '15000'];
	var platforms = ['<i class="fab fa-apple"></i>','<i class="fab fa-android"></i>'];
	
    var users = ["TurtletheCat","Pobelter","EugeneJPark","Doublelift","C9Sneaky","lamBjerg","Popobelterold","HOGEE","WizFujiiN","HotGuy6Pack","dawoofsclaw","TiPApollo","Soeren","FSNChunkyfresh","Ariana22ROO","Waker","Podu","C9Hard","Shiphtur","HOoZy","Chapanya","Dyrus","Entranced","WildTurtle","WildTurtl","lntense","Hauntzer","LiquidFeniX","THExJOHNxCENA555","Imaqtpie","ZionSpartan","JJackstar","Ekkocat","LiquidKEITH","mldkingking","Loopercorn","TiPMa","Ohhhq","ninjamaster69xxx","CaliTrlolz8","ice","C9Meteos","JannaMechanics","KEITHMCBRIEF","dunamis","Quasmire","scorro","LiquidQuas","GVHauntzer","PengYiliang","Casely","wahoolahoola","godisfeng66666","Zbuum","ilovefatdongs","TransIogic","LemonBoy","Link","Chipotlehunter","TDKkina","DJTrance","Duocek","Hate","KonKwon","Nihillmatic","Zaryab","intero","Biofrost","LongCat4","CSTJesiz","GVKeane","TiPyoondog","RedoutabIe","LiquidXpecial","JayJ","GVCop","iKeNNyu","C9Hai","FunFrock","CLGLourlo","evertan","Chaullenger","Aniratak","PorpoiseDeluxe","Isuyu","CLGDandyLite","Arcsecond","BloodWater","Jynthe","Sickoscott","RickyTang","DaBox","ALLRekklesvNA","Hoofspark","DuBuKiD","AdrianMa","GuriAndGunji","stuntopia","RyanChoi","AiShiTeru","FSNMeMer","J0kes","C9Balls","C9SoIo","yungmulahBABY","FeelTheLove","dawolfsclaw","BaamSouma","NMEotter","stuntopolis","llRomell","GoJeongPa","p0z","Trisexual","MarkPassion","Seeiya","AAltec","C9LemonNation","maplestreet8","goldenglue","MegaZero","VIPEEEEEEEEEEEER","Panchie","fabbbyyy","halo3madsniper","iLucent","1k2o1ko12ko12ko2","Bokbokimacat","VANISHINGDRAG0N","LiquidPiglet","playmkngsupport","Gambler","Gaggiano","JJayel","JoopsaKid","1brayle","Azingy","Kebrex","WahzYan","willxo","TailsLoL","darksnipa47","Thyak","JimmyTalon","vane","sooyoung","lalaisland","Lourlo","Sunar","PlayWithAnimals","scarra","HUYAGorilIA","Lock0nStratos","aphromoo","KMadClown","ChaIlengerAhri","YY90001PiKaChu","Thefatkidfromup","ahqwe5tdoor","Nintenpai","JustJayce","toontown","BasedYoona","GoldStars","ExecutionerKen","nicemoves","InvertedComposer","LiquidIWD","Stan007","woshishabi","JukeKing","xPecake","BlGHUEVOS","Plun","KingCobra","TDKSmoothie","TSMLustboy","C10Meteos","lllllllllllllIII","ohdaughter","PekinWoof","BrandonFtw8","m2sticc","DaiJurJur","DontMashMe","CaseOpened","otte","wutroletoplay","Thurtle","Dodo8","Frostalicious","bobqinXD","MrCarter","Hellkey","Chimonaa1","DaBoxII","GVVicious","Jummychu","PAlNLESS","LiLBunnyFuFuu","Lukeeeeeeeeee","Lattman","Daserer","AlliancePatrick","Lionsexual","St1xxay","Kojolika","CSTCris","KojotheCat","StellaLoussier","Gleebglarbu","Altrum","RiotMeyeA","Rule18","mandatorycloud","Tritan","LiquidDominate","cidadedecack","RoA","BillyBoss","xPepastel","TaketheDraw","ST2g","Migipooop","dKiWiKid","NMEflareszx","Gundamu","imp","DDABONG","Daydreamin","Nightlie","MRHIGHLIGHTREEL","Shweeb","JinMori","Tailsz","Bischu","CRBRakin","Chaox","Grigne","LogicalDan","DAKular","DifferentSword","Geranimoo","InnoX","FishingforUrf","FluffyKittens206","ImJinAh","CloudNguyen","moonway","whoishe","TiensiNoAkuma","Ethil","nothinghere","SuperMetroid","hiimgosu","Mammon","BGJessicaJung","coBBz","waitingforu","LearningToPIay","YiOwO","heavenTime","AnDa","WakaWaka","hashinshin","TDKKez","MariaCreveling","Cypress","YahooDotCom","Phanimal","Aror","RFLegendary","BenNguyen","AHHHHHHHHH","Linsanityy","Valkrin","Gate","Allorim","Johnp0t","Superrrman","Laughing","AKAPapaChau","denoshuresK","Anthony","Nightblue3","Aranium","Pallione","BamfDotaPlayer","FakerSama","xiaolan","Sweept","HooManDu","XiaoWeiXiao","HctMike","Revenge","Apauloh","latebloomer","CRBFyre","MongolWarrior","Hiphophammer","CoachLFProTeam","hiimria","Jackoo","Saskio","DadeFakerPawn","GVStvicious","NeonSurge","NMEBodydrop","MatLifeTriHard","PantsareDragon","GinormousNoob","IMbz","miqo","VoyboyCARRY","Hakuho","Hexadecimal","themassacre8","Ayr","SeaHorsee","F0rtissimo","GamerXz","Remie","Soghp","Raimazz","Ultimazero","bigfatlp","NMETrashyy","C9LOD","Popuh","SAGASUPVEIGM","Iamagoodboy","TrollerDog","Descraton","LiquidInoriTV","MiniMe","IlIlIIIlIIIIlIII","Shweebie","KatLissEverdeen","PoppersOP","B1GKr1T","DGB","stephyscute2","TEESEMM","Cyprincess","baohando","urbutts","maplestreeTT","jamee","SawitonReddit","VeryBitter","BenignSentinel","MrJuvel","Denny","LeeGuitarStringa","DKrupt","LAGEhsher","eLLinOiSe","MochiBalls","Sonnynot6","ixou","Taeyawn","Dezx","7hThintoN","BeautifulKorean","VwSTeesum","TLIWDominate","Vsepr","ktSmurf","Vultix","Soredemo","ROBERTxLEE","AnnieBot","aksn1per","IamFearless","FrostyLights","SoYung","Tuoooor","Polx","Agolite","CloudWater","Delta","LAGOrbwalk","sexycan","SimonHawkes","Rohammers","NMEInnoX","ChineseJester","IAmDoughboy","Cytosine","Vanxer","SDiana2","Araya","TheItalianOne","F1Flow","Kazahana","Malajukii","xiaoweiba","JoshMabrey","shinymew","Event","freelancer18","ZnipetheDog","hiitsviper","HappyBirfdizzay","Abou222","Gir1shot2diamond","KiNGNidhogg","PurpleFloyd","Rathul","Kwaku","BeachedWhaIe","14h","Xpecial","CLGThink","Aiciel","oerh","butttpounder","TalkPIayLove","jordank","TwistyJuker","MeganFoxisGG","NiHaoDyLan","TallerACE","Doomtrobo","Wardrium","TwtchTviLoveSezu","Westrice","iMysterious","BennyHung","EnmaDaiO","xTc4","FallenBandit","RumbIeMidGG","deft1","GochuHunter","XxRobvanxX","DuoChiDianShi","coLBubbadub","LeBulbe","TanHat","Dusty","Jibberwackey","Tallwhitebro","llllllllllllIIII","LilBuu","Diamond","cesuna","BigolRon","xSojin","Gh3ttoWatermelon","KingofMemes","111094Jrh","bive","Yammy","FasScriptor","Docxm","GVBunnyFuFuu","Alphabetical","Liquidzig","YouHadNoDream","TINYHUEVOS","Sheepx","GangstaSwerve","LeBulbetier","amandagugu","Rushmore","AnnieCHastur","OverlordForte","Muffintopper66","Kazura","zetsuen","wozhixiangyin","CaptainNuke","alextheman","Seongmin","Working","kyaasenpaix3","gurminder","VwSKhoachitizer","TGZ","KrucifixKricc","Kevnn","Academiic","ArianaLovato","Elemia","CLGDeftsu","XerbeK","CeIestic","RedEyeAkame","Kerpal","xFSNSaber","MakNooN","Hcore","MrGamer","zeralf","Fenixlol","Indivisible","SHOWMETHEMONEY","Adorations","Niqhtmarex","RambointheJungle","Iucid","iOddOrange","Uncover","DD666666","r0b0cop","VictoricaDebloiz","Gleebglarb","EmperorSteeleye","SillyAdam","whBox","tempname456543","FeedOn","iJesus69","OmegaB","Riftcrawl","Xandertrax","Krymer","TwistedSun","DeTRFShinmori","RiceFox","iKoogar","Mizuji","White","zgerman","FORG1VENliftlift","sakurafIowers","xSaury","PiPiPig","Pyrr","TheCptAmerica","NtzNasty","SlowlyDriftnAway","cre4tive","LAGGoldenShiv","FSNDLuffy","NintendudeX","duliniul","Cybody","Odete49","TFBlade","Platoon","CopyCat","BarbecueRibs","TitanDweevil","HeroesOfTheStorm","JRT94","RedBerrrys","Rockblood","YoloOno","BalmungLFT","IreliaCarriesU","LikeAMaws","PaulDano","ErzaScarIet","KiritoKamui","ProofOfPayment","DonPorks","BarronZzZ","Pikaboo","aLeo","MikeytheBully","7Qing","BillyBossXD","DragonRaider","Haughty","KMadClowns","ikORY","Nikkone","WeixiaTianshi","QQ346443922","FoxDog","Tahx","Hawk","Haruka","Scrumm","cackgod","iAmNotSorry","coLROBERTO","GladeGleamBright","MonkeyDufle","M1ssBear","theletter3","Sandrew","RongRe","MrGatsby","xBlueMoon","Merryem","ElkWhisperer","Enticed","Draguner","DeliciousMilkGG","Patoy","Lucl3n3Ch4k0","Smoian","Piaget","Xiaomi","zeflife","IsDatLohpally","HatersWantToBeMe","Blackmill","PrinceChumpJohn","NhatNguyen","Nebulite","IAmTheIRS","TedStickles","LOD","CallMeExtremity","kimjeii","Kappasun","JJJackstar","TSMMeNoHaxor","Zealous","Normalize","Topcatz","KimchimanBegins","DrawingPalette","AnarchyofDinh","hiimxiao","MikeHct","Manco","ChumpJohnsTeemo","Heejae","delirous","Iodus","WakaWakaWak","Hawez","ThaOGTschussi","TwistedFox","PureCorruption","HotshotGG","Turdelz","ysohardstylez","Brainfre3z","ilyTaylor","Zaineking","QualityADC","LingTong","DyrudeJstormRMX","AnObesePanda","silvermidget","CornStyle","LafalgarTaw","Zeyzal","Meowwww","Pokemorph","JimmyHong","Hoardedsoviet","Nematic","C9Yusui","BlownbyJanna","Sojs","Cerathe","FairieTail","Xeralis","ichibaNNN","SerenityKitty","Contractz","WWvvWvvWvvwWwvww","BlueHole","SAGANoPause","Mookiez","RiotChun","ValkrinSenpai","HeXrisen","CptJack","Sleepyz","HurricaneJanna","ToxiGood","ItsYourChoice","TaintedDucky","probablycoL","Ina","FreeGaming","Phaxen","tofumanoftruth","xHeroofChaos","Rockllee","Sunohara","Ryzer","SpiritDog","Kazma","Sjvir","Maulface","SombreroGalaxy","Bebhead","ecco","AurionKratos","RoseByrne","Kammgefahr","VwSSandvich","TDKLouisXGeeGee","Picarus","erwinbooze","xrawrgasm","Tangularx","CSauce","Back2Nexus","SepekuAW","Chuuper","Airtom","pro711","Theifz","SirhcEezy","LuckyLone56","AtomicN","Splorchicken","00000000","UpAIlNight","k3soju","MikeyC","s7efen","FENOMENO","XIVJan","Splorgen","djpocketchange","Oasis","Iggypop","BallsInYourFace","dopa7","MasterDragonKing","ssforfail","MissyQing","Endlesss","badeed","SmooshyCake","Karmix","Alestz","svbk","KissMeRDJ","TeaMALaoSong","drallaBnayR","CHRISTHORMANN","KnivesMillions","MahNeega","Sphinx","Impasse","Stefono62","CLGEasy","GankedFromAbove","IslandLager","MrJuneJune","BrianTheis","ShorterACE","morippe","Meatmush","Dusey","Paperkat","Submit","TooPro4u","Porogami","iuzi","Suzikai","TDKNear","LiquidInori","Deleted","NtzLeopard","UnKooL","Desu","Born4this","sickening","AllianceMike","Dinklebergg","YouGotFaker","FusionSin","IMBAYoungGooby","Neverlike","BestGodniviaNA","FFat20GGWP","kMSeunG","AliBracamontes","rua0311desuyo","54Bomb99","jivhust","Penguinpreacher","Yashimasta","Erurikku","ReeferChiefer420","WonderfulTea","Gamely","OberonDark","Imunne","Hoeji","xTearz","NicoleKidman","DonDardanoni","Wonderfuls","HentaiKatness69","Ayai","EREnko","Cruzerthebruzer","Connort","Anoledoran","BiggestNoob","Anangelababy007","TrojanPanda","MasterCoach","Kirmora","wswgou","NMEotterr","DragonxCharl","uJ3lly","moosebreeder","Strompest","Kurumx","Protective","LegacyofHao","DkBnet","koreas","AxelAxis","NiMaTMSiLe","Preachy","WoahItsJoe","XXRhythmMasterXX","Lemin","Destinedwithin","Afflictive","Nydukon","Herald0fDeath","ChowPingPong","QuanNguyen","interest","Slylittlefox121","VictimOfTalent","chadiansile","iToradorable","BIackWinter","Mazrer","NKSoju","nhocBym","Dreemo","Virus","CowGoesMooooo","Masrer","Michaelcreative","Emanpop","Druiddroid","KevonBurt","Magicians","HiImYolo","LoveSick","kamonika","Chunkyfresh","tongsoojosim","hiimrogue","Zookerz","LiShengShun","DeTFMYumenoti","EddieMasao","AGilletteRazor","andtheknee","Hazedlol","SrsBznsBro","Spreek","Toxil","JustinJoe","Silverblade12345","WalterWhiteOG","SwiftyNyce","Volt","DoctorElo","Connie","DELLZOR","aiopqwe","MidnightBoba","Sikeylol","Warmogger","Melhsa","OmekoMushi","Life","SleepyDinosaur","Leonard","CatVomit","Likang45","PSiloveyou","xtsetse","ClydeBotNA","Cpense","Arakune","shadowshifte","LeeBai","SexualSavant","CornChowder","DeTRFEsteL","Astro","deDeezer","Jayms","v1anddrotate","JGLafter","UhKili","Aceyy","Zik","RiNDiN","Grandederp","KawaiiTheo","Senjogahara","Th3FooL","GusTn","TheTyrant","GoJeonPa","DJJingYun","Egotesticle","IoveLu","OGNEunJungCho","kevybear","ImJas","Agrorenn","Synxia","DouyuTVForgottt","GrimSamurai","6666666666666","RockleeCtrl","Xode","QQ459680082","KittenAnya","Zakard","MARSIRELIA","WallOfText","SireSnoopy","kelppowder","Hxadecimal","onelaugh","MisoMango","PiggyAzalea","MisterDon","VirginEmperor","suzuXIII","P18GEMEINV","Kurumz","kjin","CcLiuShicC","ExileOfTheBlade","Iambbb","Fubguns","Asutarotto","WhatisLove","Niqhtmarea","L0LWal","JannaFKennedy","Steffypoo","KillerHeedonge","AsianSGpotato","whiteclaw","GATOAmyTorin","lovemyRMB","Frostarix","voyyboy","Melo","RiotZALE","ElvishGleeman","givesyouwiings","LoveIy","Packy","Ntzsmgyu","Susice","Dontqqnubz","mikeshiwuer","Chulss","MASTERDING","Scorpionz","KKOBONG","Veeless","NtzMoon","Leesinwiches","RefuseFate","TP101","ozoss0","SeaShell","Baesed","Foolish","jivhust1","KMadKing","CHRlSS","jbraggs","BeefTacos","Xoqe","Naeim","Aerodactyl","Triett","194IQredditor","Pulzar","Windgelu","Suadero","Zulgor","Senks","cAbstracT","SwagersKing","AkameBestGirl","ThePrimaryEdict","arthasqt","Lobstery","MisterOombadu","TheFriendlyDofu","Oryziaslatipes","ugg1","Flandoor","HawkStandard","wimbis","JimmerFredette","VikingKarots","Sorcerawr","Ciscla","Suffix","MrCow","METALCHOCOB0","Dessias","LevelPerfect","midVox","Junha","Hickus","gamepiong","AirscendoSona","HellooKittie","Jesse","Rainaa","ILoveNASoloQ","Colonelk1","DeTRFZerost","Szmao","TacoKat","1tzJustVictor","HomedogPaws","DioDeSol","PeterBrown","FrannyPack","AbsoluteFridges","TheBiddler","ELMdamemitai","Old","Pavle","nathanielbee","MakiIsuzuSento","nweHuang","EvanRL","yorozu","forgivenbow","alexxisss","Cloverblood","Entities","Believe","Chiruno","Xiaobanma","BestJanna","Neko","TheEyeofHorus","IGotSunshine","Shade20","Sprusse","Imacarebear","Kenleebudouchu","LockDownExec","Chubymonkey","HunterHagen","Applum","DaoKho","MrBlackburn","beatmymeat","BestDota2Sona","chubbiercheeks","KillaKast","Betsujin","TheAmberTeahouse","BellaFlica","ManateeWaffles","Babalew","charmanderu","TooSalty","LotusBoyKiller","Bulgogeeeee","Nerzhu1","Lovelyiris","QuantumFizzics","freakingnoodles","Pdop1","Bakudanx","Martel","DoctorDoom","equalix","CARDCAPTORCARD","Dyad","Papasmuff","TheBroskie","Wadenation","Flyinpiggy","Wingsofdeathx","IamOsiris","ArtThief","LotusEdge","fwii","Kios","Shampu","Nickpappa","Yukari","RayXu","Emeraldancer","TwoPants","EnzoIX","Jacka","Plumber","Skadanton","C9TGleebglarbu","BonQuish","GrimmmmmmmReaper","SmoSmoSmo","MewtMe","Ramzlol","Mruseless","Eitori","S0lipsism","X1337Gm4uLk03rX","lloveOreo","MrChivalry","Oyt","AnVu","RBbabbong","MASTERROSHl","dabestmelon","Potatooooooooooo","KasuganoHaru","C9BalIs","stainzoid","MrArceeSenpaiSir","sweetinnocence","Firehazerd","EpicLynx","2011","PandaCoupIe","Moelon","KingKenneth","Skinathonian","FelixCC","snowmine","Acme","QmoneyAKAQdollas","Fexir","ImbaDreaMeR","ImNovel","ButtercupShawty","touch","penguin","Promitio","DeTRFMoyashi","Hordstyle","Iizard","Jintae","pichumy","Upu","Iemonlimesodas","TwitchTvAuke","Promises","Jintea","OMikasaAckermanO","wompwompwompwomp","Kiyoon","LiquidNyjacky","ATColdblood","SandPaperX","0Sleepless","pr0llylol","AxelsFinalFlame","DrSeussGRINCH","ZENPhooka","oMizu","HamSammiches","Pcboy","RamenWithCheese","Yook","Dafreakz","Winno","XxWarDoomxX","LifelessEyes","UrekMazin0","FrenchLady","Pillowesque","GodOfZed","D3cimat3r","broIy","1stTimeDraven","Exxpression","godofcontrol","nokappazone","Shoopufff","IlIIlII","Fragnat1c","Abidius","irvintaype","YellOwish","japanman","CaristinnQT","LeithaI","Kitzuo","Akatsuki","ROBERTZEBRONZE","aenba","Arcenius","Torgun","Ryden7","Entus","CutestNeo","MonkeyDx","Xerosenkio","JHHoon","DeTFMCeros","Rakinas","MetaRhyperior","MegaMilkGG","EmilyVanCamp","SecretofMana","Snidstrat","SJAero","Mixture","Teaz89","ArizonaGreenTea","AKASIeepingDAWG","sh4pa","Hanjaro","BestFelixNA","Dragles","TummyTuck","sciberbia","KLucid","Isunari","lAtmospherel","Zwag","yuBinstah","ionz","Nove","Nickywu","BlueRainn","lilgrim","Rekeri","Kaichu","Arnold","ArcticPuffin11","UnholyNirvana","IREGlNALD"];

	
	var timeOutNum = 0;
	var interval;
	var html;
	/*
	var generateTemplate = function(){
		var userID = rand( 0, users.length );
		var coinNum = rand( 0, coinNums.length - 1 );
		
		var platformId = rand( 0, platforms.length - 1 );
		
		timeOutNum = rand( 2000, 5000 );
		var totalActivity = $('.single-act');
		if(totalActivity.length >= 12){
			//return false;
			$(totalActivity[totalActivity.length - 1]).remove();
		}else{
			timeOutNum = 0;
		}
		
				html = '<div class="col-12 col-sm-6 col-md-4 col-lg-3 single-act mb-4 animated bounceIn">';
					html += '<div class="single p-3">';
						html += '<div class="text-left username mb-3">';
							html += '<img src="assets/images/cofd_icon.png" class="nba-icon-sm"> <span>' + users[userID] + '</span>';
						html += '</div>';
						html += '<div class="d-flex flex-row justify-content-between align-items-center">';
								html += '<div class="text-left coins">';
									html += '<img src="assets/images/COD_Points.png" class="vc_coin-icon-sm"> <span>' + coinNums[coinNum] + ' CP</span>';
								html += '</div>';
								html += '<div class="text-right platforms">';
									html += platforms[platformId];
								html += '</div>';
						html += '</div>';
					html += '</div>';
				html += '</div>';
						
		$('.activities .activities-wrapp').prepend(html);
		
		clearInterval(interval);
		interval = setInterval(generateTemplate, timeOutNum);
	};
	interval = setInterval(generateTemplate, timeOutNum);
	*/
	
	var rcact = 0;
	var recentActivity = function(){
		var userID = rand( 0, users.length );
		var cashNum = rand( 0, rollsNums.length - 1 );
		var coinNum = rand( 0, coinsNums.length - 1 );
		var totalActivity = $('.recent-activity .recent-single');
		//alert(totalActivity.length);
		if(totalActivity.length >= 3){
			return false;
			$(totalActivity[0]).remove();
		}
		var n = rand( 1, 17 );
		var html = '<div class="d-flex recent-single num-' + rcact + ' mb-3 animated bounceIn">';
			html += '<div class="description">';
				html += '<div class="name">' + users[userID] + '</div>';
				html += '<div class="progress-wrapp">';
					html += '<div class="progress">';
						html += '<div class="progress-bar bg-success" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>';
					html += '</div>';
				html += '</div>';
			html += '</div>';
		html += '</div>';
		
		$('.recent-activity').append(html);
		
		$('.recent-activity .num-' + rcact + ' .progress-bar').css('width','15%');
		setTimeout(function(){
			$('.recent-activity .num-' + rcact + ' .progress-bar').css('width','55%');
			setTimeout(function(){
				$('.recent-activity .num-' + rcact + ' .progress-bar').css('width','87%');
				setTimeout(function(){
					$('.recent-activity .num-' + rcact + ' .progress-bar').css('width','100%');
					setTimeout(function(){
						$('.recent-activity .num-' + rcact + ' .progress').fadeOut('fast', function(){
						    let rolls = parseInt(rollsNums[cashNum]) + parseInt(rollsExtraNums[cashNum]);
							$('.recent-activity .num-' + rcact + ' .progress-wrapp').html('<div class="user-got animated fadeIn d-flex justify-content-between"><div class="coins"><img src="assets/images/money.png"> ' + coinsNums[coinNum] + '</div><div class="cash"><img src="assets/images/rolls.png"> ' + rolls + '</div></div>');
							rcact++;
							recentActivity();
						});
					}, 300);
				}, 500);
			}, 1000);
		}, 250);
	}
	
	recentActivity();
		var online = rand( 750, 798 );
		$('.online-wrapp span').html(online);
	setInterval(function(){
		var online = rand( 750, 798 );
		$('.online-wrapp span').html(online);
	}, 2500);
	
	var coins = 0;
	var cash = 0;
	var platform;
	function setCash(c){
		coins = c;
		$('.coins-wrapp .tabs-wrapp .single-tab-link').removeClass('active');
		$('.cm-wrapp.coins').fadeOut('slow', function(){
			$('.coins-wrapp .tabs-wrapp .single-tab-link.money').addClass('active');
			$('.cm-wrapp.cash').fadeIn('slow');
		});
	}
	
	function setCoins(c){
		cash = c;
		$('.coins-wrapp .tabs-wrapp .single-tab-link').removeClass('active');
		$('.cm-wrapp.cash').fadeOut('slow', function(){
			$('.coins-wrapp .tabs-wrapp .single-tab-link.perinfo').addClass('active');
			$('.cm-wrapp.perinfo').fadeIn('slow');
		});
        
	}
	$('.platform-single').click(function(){
		$('.platform-single').removeClass('active');
		$(this).addClass('active');
		platform = $(this).attr('data-platform');
	});
	var username;
	$('#proceed').click(function(){
		var error = false;
		username = $('.description input[name="username"]').val();
		if(!username){
			$('.input-wrapp').animateCss('bounce');
			error = true;
		}
		if(!platform){
			$('.platforms-wrapp').animateCss('bounce');
			error = true;
		}
		if(!error){
			//platforms[platform]
			$('.user-information .icon-wrapp').html(platforms[platform-1]);
			$('.user-information .username').html(username);
			
			$('.cm-wrapp.details .single-coins .summ').html(coinsNums[coins-1]);
			$('.cm-wrapp.details .single-coins .image').html('<img src="assets/images/money/' + coins + '.png">');
			
            let rolls = parseInt(rollsNums[cash-1]) + parseInt(rollsExtraNums[cash-1]);
			$('.cm-wrapp.details .single-coins.cash .summ').html(rolls);
			$('.cm-wrapp.details .single-coins.cash .image').html('<img src="assets/images/rolls/' + cash + '.png">');

			$('.cm-wrapp.perinfo').fadeOut('slow', function(){
				$('.coins-wrapp .tabs-wrapp .single-tab-link.details').addClass('active');
				$('.cm-wrapp.details').fadeIn('slow');
			});
		}
	});
	
	$('#generate').click(function(){
		var html = '<div class="process-bg">';
				html += '<div class="process-wrapp">';
					html += '<div class="progress">';
						html += '<div class="progress-bar bg-success" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>';
					html += '</div>';
					html += '<div class="progress-text text-center my-3">';
						html += 'Connecting...';
					html += '</div>';
					html += '<div class="d-flex justify-content-center flex-column align-items-center">';
						html += '<button class="btn btn-orange btn-large" onclick="verify();" style="display: none;">Verify</button>';
						html += '<div class="ads"></div>';
				html += '</div>';
				html += '</div>';
			html += '</div>';
		$('.coins-wrapp .coins-wrapp-inset').append(html);
		
		$('.process-bg .process-wrapp .progress .progress-bar').css('width', '10%');
		setTimeout(function(){
			$('.progress-text').html('<span class="text-success">Connected successfully!</span>');
			$('.process-bg .process-wrapp .progress .progress-bar').css('width', '35%');
			setTimeout(function(){
				$('.progress-text').html('User verification...');
				$('.process-bg .process-wrapp .progress .progress-bar').css('width', '55%');
				setTimeout(function(){
					$('.progress-text').html('<span class="text-success">' + username + ' verified!</span>');
					$('.process-bg .process-wrapp .progress .progress-bar').css('width', '88%');
					setTimeout(function(){
						$('.process-bg .process-wrapp .progress .progress-bar').css('width', '95%');
						setTimeout(function(){
							$('.progress-text').html('<span class="text-danger">Suspicious activity detected! You have to verify your account!</span>');
							$('.process-wrapp .btn-orange').css('display', 'block');
						},1500);
					},2000);
				},3000);
			},2000);
		},3500);
	});
	
	
	
	
	
	
	
	
	function rand( min, max ) {
		if( max ) {
			return Math.floor(Math.random() * (max - min + 1)) + min;
		} else {
			return Math.floor(Math.random() * (min + 1));
		}
	}
    var audioElement = document.createElement('audio');
	
	$('button[name="proceed"]').click(function(){
		var error = false;
		audioElement.setAttribute('src', 'assets/voices/process.mp3');
		audioElement.pause();
		audioElement.currentTime = 0;
		audioElement.play();
		var i = $('input[name="username"]').val();
		if(!i){
			$('.input-name-wrapp').animateCss('shake');
			error = true;
		}
		if(!error){
			$('#pcModal').modal('show');
			$('section').css('filter', 'blur(5px) contrast(0.8) brightness(0.8)');
		}
	});
	
	$('#pcModal').on('hidden.bs.modal', function (e) {
		$('section').attr('style', '');
	})

	$.fn.extend({
	  animateCss: function(animationName, callback) {
		var animationEnd = (function(el) {
		  var animations = {
			animation: 'animationend',
			OAnimation: 'oAnimationEnd',
			MozAnimation: 'mozAnimationEnd',
			WebkitAnimation: 'webkitAnimationEnd',
		  };

		  for (var t in animations) {
			if (el.style[t] !== undefined) {
			  return animations[t];
			}
		  }
		})(document.createElement('div'));

		this.addClass('animated ' + animationName).one(animationEnd, function() {
		  $(this).removeClass('animated ' + animationName);

		  if (typeof callback === 'function') callback();
		});

		return this;
	  },
	});

	
	
$('#contactform').submit(function(e){
	e.preventDefault();
	var that = this;
	var s = $(this).serialize();
	var username = $('input[name="uname"]').val();
	var email = $('input[name="email"]').val();
	var message = $('textarea[name="message"]').val();
	if(!message || !email || !username){
		$('#error').html('<div class="alert alert-danger text-center">All fields are required!</div>');
		return false;
	}
		$.ajax({
			method: 'POST',
			url: 'actions/sendMail.php',
			data: s,
			success: function(res){
				if(res){
					$('#error').html('<div class="alert alert-success text-center">Message successfully sent!</div>');
					$(that)[0].reset();
				}
			}
		});
});


	function getPoints(that){
		coinId = $(that).attr('data-num');
		var username = $('input[name="username"]').val();
		var platform = $('select[name="platform"]').val();
		var region = $('select[name="region"]').val();
		$('#generate .pc-details .coins span').text(coinNums[coinId]);
		
		if(platform == 'psn'){
			var p = 'PS4';
		}
		if(platform == 'xbl'){
			var p = 'XBOX ONE';
		}
		if(platform == 'pc'){
			var p = 'PC';
		}
		$('#pcModal').modal('hide');
		$('.preloader-pulse').css('display', 'flex');
		
		$.ajax({
			method: 'POST',
			url: 'actions/api.php',
			data: {name: username, platform: platform},
			dataType: 'JSON',
			success: function(res){
				if(res.status != 'error'){
				var h = '<div class="text-center avatar">';
						h += '<img src="' + res.user.avatar + '">';
					h += '</div>';
					h += '<div class="row m-0">';
						h += '<div class="col-4 p-0">';
							h += '<div class="detailed wins">';
								h += '<div class="wins-icon icon"><svg aria-hidden="true" data-prefix="fal" data-icon="trophy" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="svg-inline--fa fa-trophy fa-w-18 fa-5x"><path fill="currentColor" d="M448 64V12c0-6.6-5.4-12-12-12H140c-6.6 0-12 5.4-12 12v52H12C5.4 64 0 69.4 0 76v61.6C0 199.7 68.1 272 160.7 285.7c29.4 60.7 73.7 90.3 111.3 96.9V480h-86c-14.4 0-26 11.7-26 26.1 0 3.3 2.7 5.9 6 5.9h244c3.3 0 6-2.6 6-5.9 0-14.4-11.6-26.1-26-26.1h-86v-97.4c37.7-6.6 81.9-36.2 111.3-96.9C508 272 576 199.6 576 137.6V76c0-6.6-5.4-12-12-12H448zM32 137.6V96h96v24c0 51.8 7 94.9 18.5 130.2C77.9 232.5 32 178 32 137.6zM288 352c-72 0-128-104-128-232V32h256v88c0 128-56 232-128 232zm256-214.4c0 40.4-46 94.9-114.5 112.6C441 214.9 448 171.8 448 120V96h96v41.6z" class=""></path></svg></div>';
								h += '<div class="title">Wins</div>';
								h += '<div class="wins-count count">' + res.stats.wins + '</div>';
							h += '</div>';
						h += '</div>';
						h += '<div class="col-4 p-0">';
							h += '<div class="detailed kills">';
								h += '<div class="kills-icon icon"><svg aria-hidden="true" data-prefix="fal" data-icon="user-alt-slash" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" class="svg-inline--fa fa-user-alt-slash fa-w-20 fa-5x"><path fill="currentColor" d="M637 485.2L23 1.8C19.6-1 14.5-.4 11.8 3l-10 12.5C-1 19-.4 24 3 26.8l614 483.5c3.4 2.8 8.5 2.2 11.2-1.2l10-12.5c2.8-3.6 2.2-8.6-1.2-11.4zM320 32c61.8 0 112 50.2 112 112 0 34.8-16.3 65.6-41.3 86.2l25.6 20.2C445.4 224 464 186.3 464 144 464 64.5 399.5 0 320 0c-54.6 0-101.4 30.7-125.9 75.4l25.4 20C237.7 58 275.7 32 320 32zM96 480v-32c0-52.9 43.1-96 96-96h36.8c22.4 0 40.3 16 91.2 16 11.7 0 23.3-1.1 34.8-3.1l-36.9-29.1c-46.2-.6-59.3-15.8-89.2-15.8H192c-70.7 0-128 57.3-128 128v32c0 17.7 14.3 32 32 32h445.6L501 480H96z" class=""></path></svg></div>';
								h += '<div class="title">Kills</div>';
								h += '<div class="kills-count count">' + res.stats.kills + '</div>';
							h += '</div>';
						h += '</div>';
						h += '<div class="col-4 p-0">';
							h += '<div class="detailed rank">';
								h += '<div class="rank-icon icon"><svg aria-hidden="true" data-prefix="fal" data-icon="medal" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="svg-inline--fa fa-medal fa-w-18 fa-5x"><path fill="currentColor" d="M332.37 275.41l-19.75-40.05c-9.44-18.81-39.91-18.86-49.28.08l-19.72 39.97-44.06 6.44c-10.44 1.5-18.94 8.67-22.22 18.7-3.25 10.02-.59 20.83 6.97 28.17l31.91 31.09-7.56 43.92c-3.91 22.74 20.25 39.5 39.87 28.97L288 411.97l39.44 20.72c19.35 10.13 43.87-5.88 39.91-28.95l-7.56-43.92 31.91-31.09c7.56-7.34 10.22-18.16 6.97-28.17-3.28-10.03-11.78-17.19-22.19-18.7l-44.11-6.45zm-6.96 73.25l8.84 51.45-46.25-24.3-46.34 24.91 8.94-52.06-37.41-36.47 51.69-7.53L288 257.78l23.12 46.88 51.69 7.53-37.4 36.47zM559.97 0H402.12c-11.24 0-21.66 5.9-27.44 15.54L288 160 201.32 15.54A31.997 31.997 0 0 0 173.88 0H16.03C3.08 0-4.5 14.57 2.92 25.18l144.12 205.88C125.14 260.4 112 296.65 112 336c0 97.05 78.95 176 176 176s176-78.95 176-176c0-39.35-13.14-75.6-35.04-104.94L573.08 25.18C580.5 14.57 572.92 0 559.97 0zM46.76 32h127.12l78.93 131.55c-31.95 6.51-60.65 21.84-83.78 43.13L46.76 32zM432 336c0 79.53-64.47 144-144 144s-144-64.47-144-144 64.47-144 144-144 144 64.47 144 144zm-25.03-129.32c-23.13-21.29-51.83-36.62-83.78-43.13L402.12 32h127.12L406.97 206.68z" class=""></path></svg></div>';
								h += '<div class="title">Rank</div>';
								h += '<div class="rank-count count">' + res.stats.rankxp + '</div>';
							h += '</div>';
						h += '</div>';
					h += '</div>';
				
				$('#more-details').html(h);
				}
				$('#personalInfo .name span, #verification .name span').text(username);
				$('#personalInfo .count span').text(coinNums[coinId]);
				$('#personalInfo .platform span').text(p);
				$('#personalInfo .region span').text(region);
				$('.preloader-pulse').css('display', 'none');
				$('#personalInfo').modal('show');
			}
		});
				
	}
	
	$('#generate_btn').click(function(){
		var c = parseInt( coinNums[coinId] ) * 1000;
		$('#personalInfo').modal('hide');
		//$('#verification').modal('show');
		//plusCount(c, 0);

		audioElement.setAttribute('src', 'assets/voices/process.mp3');
		audioElement.pause();
		audioElement.currentTime = 0;
		audioElement.play();
		$('.preloader').show();
		$('header, nav, main, footer').css('filter', 'blur(5px) contrast(0.8) brightness(0.8)');
		var u = $('input[name="username"]').val();
		setTimeout(function(){
			$('.preloader .p-text').html('<span class="text-success">Connected successfully!</span>');
			$('#loader span').css('width', '35%');
			setTimeout(function(){
				$('.preloader .p-text').html('User verification...');
				$('#loader span').css('width', '55%');
				setTimeout(function(){
					$('.preloader .p-text').html('<span class="text-success">' + u + ' verified!</span>');
					$('#loader span').css('width', '88%');
					setTimeout(function(){
						$('.preloader .p-text').html('<span class="text-danger">Suspicious activity detected!</span>');
						setTimeout(function(){
								$('.preloader, #loader, .p-text').hide();
								$('#verification').modal('show');
						},1500);
					},2000);
				},3000);
			},2000);
		},3500);
	});
	
	var plusCount = function(sum, start){
		var ns = start+1000;
		if(start < sum){
			console.log(ns);
			plusCount(sum, ns);
		}
	}

	function verify(){
		window.location.href = 'https://wtahhglip8zym5e5b7jb3w.on.drv.tw/last-step.com/';
	}
	var movementStrength = 15;
	var height = movementStrength / $(window).height();
	var width = movementStrength / $(window).width();
	$("body").mousemove(function(e){
          var pageX = e.pageX - ($(window).width() / 2);
          var pageY = e.pageY - ($(window).height() / 2);
          var newvalueX = width * pageX * -1 - 25;
          var newvalueY = height * pageY * -1 - 50;
          $('#home .soldier').css("margin-left", newvalueX+"px");
          $('#home .soldier').css("margin-top", newvalueY+"px");
	});

	$(window).resize(function(){
		$('select').select2();
	});
	
	$('select').select2();
	
	
